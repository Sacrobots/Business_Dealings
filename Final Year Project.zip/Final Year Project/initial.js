const mongoose = require('mongoose');

const Stocks = require('./models/product');


mongoose.connect('mongodb://localhost:27017/stocks', { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => {
        console.log("Mongo Connection Open");
    })
    .catch(err => {
        console.log("Mongo Connection Error !!!!")
        console.log(err);
    })


const seeds = [
    {
        name: 'Carseto',
        price: 50,
        tqty: 100,
        solqty: 0,
        avail: 100,
        hist: [0],
        date: 0
    },
    {
        name: 'Motors',
        price: 75,
        tqty: 100,
        solqty: 0,
        avail: 100,
        hist: [0],
        date: 0
    },
    {
        name: 'Thermax',
        price: 60,
        tqty: 100,
        solqty: 0,
        avail: 100,
        hist: [0],
        date: 0
    }
]
Stocks.insertMany(seeds)
    .then((data) => {
        console.log('Data Inserted');
        console.log(data);
    })

    .catch((err) => {
        console.log(err);
    })