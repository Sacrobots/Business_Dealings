const express = require('express');
const app = express();

const path = require('path');

const mongoose = require('mongoose');

const methodOverride = require('method-override');
const Stocks = require('./models/product');
const { compile } = require('ejs');
const bcrypt = require('bcrypt');
const User = require('./models/user');

mongoose.connect('mongodb://localhost:27017/stocks', { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => {
        console.log("Mongo Connection Open");
    })
    .catch(err => {
        console.log("Mongo Connection Error !!!!")
        console.log(err);
    })


app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
app.use(express.urlencoded({ extended: true }));
app.use(methodOverride('_method'));
app.use(express.static(path.join(__dirname, 'public')));


app.get('/stocks', (req, res) => {
    res.render('stocks/user.ejs')
})


// -------------------------------------------------------------------------------------------------


// --------------------------------------------------------------------------------------------------


app.get('/stocks/server', async (req, res) => {
    const stocks = await Stocks.find({});
    console.log(stocks);
    res.render('stocks/inventory', { stocks });
})
app.get('/stocks/ahome', async (req, res) => {
    const stocks = await Stocks.find({});
    res.render('stocks/admin', { stocks });
})


app.get('/stocks/chome', async (req, res) => {
    const stocks = await Stocks.find({});
    res.render('stocks/home.ejs', { stocks });
})
app.get('/stocks/prod', (req, res) => {
    res.render('stocks/user2ndpage');
})

// -----------------------------------------------------------------------

app.get('/stocks/client', async (req, res) => {
    const stocks = await Stocks.find({});
    console.log(stocks);
    res.render('stocks/Purchased', { stocks });
})


// ----------------------------------------------------------------------
// buystocks





app.get('/stocks/:id', async (req, res) => {
    const { id } = req.params;
    const stocks = await Stocks.findById(id);
    res.render('stocks/purchaseSuccess.ejs', { stocks })
})

app.get('/stocks/:id/edit', async (req, res) => {
    const { id } = req.params;
    const stocks = await Stocks.findById(id);
    res.render('stocks/buystocks', { stocks })
})
















// --------------------------------------------------------------------------
// Time, Date 
app.put('/stocks/:id', async (req, res) => {
    const { id } = req.params;

    const stocks = await Stocks.findById(id);

    stocks.solqty += parseInt(req.body.solqty);

    stocks.hist.push(parseInt(req.body.solqty));



    let dateObj = new Date();
    let month = dateObj.getUTCMonth() + 1; //months from 1-12
    let day = dateObj.getUTCDate();
    let year = dateObj.getUTCFullYear();

    let thours = dateObj.getHours();
    let tmins = dateObj.getMinutes();
    let tsecs = dateObj.getSeconds();


    let newdate = ('0' + day).slice(-2) + "-" + ('0' + month).slice(-2) + "-" + year + " " + ('0' + thours).slice(-2) + ':' + ('0' + tmins).slice(-2) + ':' + ('0' + tsecs).slice(-2);

    stocks.date.push(newdate);

    await stocks.save();
    res.redirect(`/stocks/${stocks._id}`);
})
// -------------------------------------------------------------------------
// History 

app.get('/checkHis', (req, res) => {
    res.render('stocks/clienthistory');
})


app.get('/check/:id/history', async (req, res) => {
    const { id } = req.params;
    const stocks = await Stocks.findById(id);
    res.render('stocks/history', { stocks })
})


// Login Verification ---------------------------------------------------
app.get('/login', (req, res) => {
    res.render('stocks/login');
})
app.post('/login', async (req, res) => {
    const { username, password } = req.body;
    const user = await User.findOne({ username });

    const valid = await bcrypt.compare(password, user.password);

    if (username == 'client' && valid) {
        res.redirect('/stocks/chome')
    }
    else if (username == 'admin' && valid) {
        res.redirect('/stocks/ahome');
    }
    else {
        res.redirect('/login');
    }
})

// ---------------------------------------------------------------------------




app.get('/update', async (req, res) => {
    res.render('stocks/adminupdate');
})


app.get('/stocks/:id/update', async (req, res) => {
    const { id } = req.params;
    const stocks = await Stocks.findById(id);

    res.render('stocks/updateprod', { stocks })
})



app.put('/update/:id', async (req, res) => {
    const { id } = req.params;
    const stocks = await Stocks.findById(id);
    stocks.tqty += parseInt(req.body.tqty);
    stocks.price = parseInt(req.body.price);

    await stocks.save();
    res.redirect(`/update/${stocks._id}`);
})

app.get('/update/:id', async (req, res) => {
    const { id } = req.params;
    const stocks = await Stocks.findById(id);


    res.render('stocks/adminupdate', { stocks })
})

// -----------------------------------------------------------------------------
// Graph
app.get('/graph', async (req, res) => {
    const stocks = await Stocks.find({})
    console.log(stocks);
    res.render('stocks/graph', { stocks });
})

// -----------------------------------------------------------------------------


// ------------------------------------------------------------------------------

app.listen(3000, () => {
    console.log('Listening to Port 3000');
})
