const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({

    name: {
        type: String,
        required: true
    },
    price: {
        type: Number,
        required: true,
        min: 0
    },
    tqty: {
        type: Number,
        required: true,
        min: 0
    },
    solqty: {
        type: Number,
        required: true,
        min: 0
    },

    avail: {
        type: Number,
        required: true,
        min: 0
    },

    hist: {
        type: Array,
        required: true
    },

    date: {
        type: Array,
        required: true
    }
})

const Stocks = mongoose.model('Stocks', productSchema);

module.exports = Stocks;